package sh;

public class Table implements Runnable {
	
	public void run(){
		int num=2;
		System.out.print("\nTable is");
        for(int i=1;i<=10;i++) {
            System.out.print(num*i + " ");
        }
    }

}
